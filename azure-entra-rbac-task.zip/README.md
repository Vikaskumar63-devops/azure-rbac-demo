# Azure RBAC and Entra ID Management Task

This repository contains documentation and example scripts to complete the task of managing Azure subscriptions, Entra ID, users, groups, RBAC roles, and custom roles using Azure CLI.

## Task Overview

- Observe assigned Subscriptions
- Observe Azure Entra ID or create own Azure Entra ID in personal Azure account
- Create test users and groups
- Assign RBAC roles to users and test
- Create custom roles and assign to users and test

## Prerequisites

- Azure CLI installed ([Install guide](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli))
- Azure subscription access
- Permissions to create users, groups, and roles

## Step-by-step

### 1. Observe Assigned Subscriptions

```bash
az account list --output table
```

### 2. Observe Azure Entra ID or Create New Entra ID

Azure Entra ID is the new name for Azure Active Directory (Azure AD).  
To list your Azure AD tenants:

```bash
az account tenant list --output table
```

To create a new Azure AD tenant (Entra ID), currently must be done from Azure Portal.

### 3. Create Test Users and Groups

Create user:

```bash
az ad user create --display-name "Test User" --user-principal-name testuser@yourdomain.com --password "StrongPassword123!"
```

Create group:

```bash
az ad group create --display-name "Test Group" --mail-nickname "testgroup"
```

Add user to group:

```bash
az ad group member add --group "Test Group" --member-id <user-object-id>
```

### 4. Assign RBAC Role to User and Test

Assign Reader role:

```bash
az role assignment create --assignee testuser@yourdomain.com --role Reader --scope /subscriptions/<subscription-id>
```

### 5. Create Custom Role and Assign to User

Create custom role JSON file (`customRole.json`):

```json
{
  "Name": "Custom Role Name",
  "IsCustom": true,
  "Description": "Description of custom role",
  "Actions": [
    "Microsoft.Compute/virtualMachines/start/action",
    "Microsoft.Compute/virtualMachines/deallocate/action"
  ],
  "NotActions": [],
  "AssignableScopes": [
    "/subscriptions/<subscription-id>"
  ]
}
```

Create role:

```bash
az role definition create --role-definition customRole.json
```

Assign custom role to user:

```bash
az role assignment create --assignee testuser@yourdomain.com --role "Custom Role Name" --scope /subscriptions/<subscription-id>
```

## References

- [Azure CLI Documentation](https://learn.microsoft.com/en-us/cli/azure/what-is-azure-cli)
- [Video Guide](https://www.youtube.com/watch?v=-BD5rlMyLUY)

---
