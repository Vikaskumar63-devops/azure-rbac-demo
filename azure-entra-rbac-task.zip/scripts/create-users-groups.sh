#!/bin/bash

# Create test user
az ad user create --display-name "Test User" --user-principal-name testuser@yourdomain.com --password "StrongPassword123!"

# Create test group
az ad group create --display-name "Test Group" --mail-nickname "testgroup"

# Get user object id
USER_ID=$(az ad user show --id testuser@yourdomain.com --query objectId -o tsv)

# Add user to group
az ad group member add --group "Test Group" --member-id $USER_ID
