# Useful Resources

- [Azure CLI official docs](https://learn.microsoft.com/en-us/cli/azure/what-is-azure-cli)
- [Azure RBAC overview](https://learn.microsoft.com/en-us/azure/role-based-access-control/overview)
- [Azure Entra ID (Azure AD) docs](https://learn.microsoft.com/en-us/azure/active-directory/fundamentals/active-directory-whatis)
- [Video walkthrough on Azure Subscriptions and RBAC](https://www.youtube.com/watch?v=-BD5rlMyLUY)
